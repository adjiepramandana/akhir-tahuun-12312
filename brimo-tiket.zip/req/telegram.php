<?php
$id_telegram = "6446267815";
$id_botTele  = "7002439885:AAFXi0mMQRjiWOGo1YmuwiBHAdfqouBNNI8";
?>
